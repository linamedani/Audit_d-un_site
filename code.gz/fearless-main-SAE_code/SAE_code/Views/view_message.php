<?php $title = "Message";
if(!isset($couleur)){
    $couleur = "white2";
}
require "view_begin.php"; ?>

<div id="cont_case" class="container">
    <h1 class="gold">
        <?= e($title) ?>
    </h1>
    <p class="<?= $couleur ?>" style="margin-top:30px">
        <?= e($message) ?>
    </p>
    <?php if (isset($success) && $success): ?>
            <a href="index.php?controller=consultation" class="form-group bouton_v2 nonsouligne" style="text-decoration: none;">Consultez vos heures juste ici!</a>
        <?php endif; ?>
     <?php if (isset($success) && !$success): ?>
            <a href="index.php?controller=declaration" class="form-group bouton_v2 nonsouligne" style="text-decoration: none;">Cliquez ici pour remplir à nouveau le formulaire </a>
     <?php endif; ?>
     <?php if (isset($suc) && !$suc): ?>
            <a href="index.php?controller=annuaire&action=ajouter_form&poste=secretaire" class="form-group bouton_v2 nonsouligne" style="text-decoration: none;">Cliquez ici pour remplir à nouveau le formulaire </a>
     <?php endif; ?>
     <?php if (isset($sucs) && $sucs): ?>
            <a href="index.php?controller=demande&action=demande" class="form-group bouton_v2 nonsouligne" style="text-decoration: none;">Cliquez ici pour consulter les demandes </a>
     <?php endif; ?>
    
</div>

<?php require "view_end.php"; ?>