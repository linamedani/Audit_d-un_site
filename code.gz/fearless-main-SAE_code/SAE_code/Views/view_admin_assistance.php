<?php $title= "Messages d'assistance";
require "view_begin.php";
?>

<div id="cont_case" class="container">
    <h1 class="gold">Messages d'assistance</h1>
    <br>
    <div class="table-responsive">
        <table id="ass" class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Objet</th>
                    <th>Demande</th>
                    <th>Date de création</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($messages as $message): ?>
                <tr>
                    <td><?= $message['id_personne'] ?></td>
                    <td><?= e($message['nom']) ?></td>
                    <td><?= e($message['prenom']) ?></td>
                    <td><?= e($message['objet']) ?></td>
                    <td><?= e($message['demande']) ?></td>
                    <td><?= e($message['date_creation']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require "view_end.php" ?>