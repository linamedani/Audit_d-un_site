<?php require "view_begin.php"; 
$title= "Consultation heure"; ?>

<?php require "view_end.php"; ?>