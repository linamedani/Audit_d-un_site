
document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    const besoinInput = document.getElementById("besoin");
    const besoinError = document.getElementById("besoin-error");

    form.addEventListener("submit", function(event) {
        const besoinValue = besoinInput.value.trim();

        // Vérifier si l'entrée est un nombre valide
        if (!besoinValue || isNaN(besoinValue) || Number(besoinValue) <= 0) {
            besoinError.style.display = "block";
            event.preventDefault(); // Empêche la soumission du formulaire
        } else {
            besoinError.style.display = "none";
        }
    });
});
