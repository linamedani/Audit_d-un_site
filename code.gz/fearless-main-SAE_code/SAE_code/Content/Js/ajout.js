/**
 * Fonction qui permet au formulaire pour ajouter un utilisateur de vérifier les informations données par celui-ci
 * seulement en utilisant des expressions regulières.
 * @returns {boolean}
 */

function UserForm() {

    let res = true;


    // Pour vérifier si l'id est un nombre
    const IDField = document.getElementById('id');
    const IDHelp = document.getElementById('idHelp');
    let ID = IDField.value;
    let regexId = /^\d+$/;

    if (!regexId.test(ID)) {
        IDHelp.textContent = "L'ID doit contenir uniquement des chiffres.";
        res = false;
    }else{
        IDHelp.textContent = ""
    }



    // Pour vérifier le mot de passe
    const mdpField = document.getElementById('mdp');
    const mdp_verifyField = document.getElementById('mdp_verify');
    const mdpHelp = document.getElementById('mdpHelp');
    let mdp1 = mdpField.value;
    let mdp2 = mdp_verifyField.value;
    let regexMdp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/

    if (!regexMdp.test(mdp1)){ // Vérifie si le mot de passe contient un minimum de caractères valides
        mdpHelp.textContent = "Le mot de passe doit contenir au moins 8 caractères, un @$!%*?&, une majuscule et un chiffre.";
        res = false;
    }else if(mdp1 !== mdp2) {
        mdpHelp.textContent = "Le mot de passe n'est pas le même";
        res = false;
    }else{
        mdpHelp.textContent = ""
    }



    // Pour vérifier si l'email a la bonne syntaxe
    const emailField = document.getElementById('email');
    const emailHelp = document.getElementById('emailHelp');
    let email = emailField.value;
    let regexMail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!regexMail.test(email)) {
        emailHelp.textContent = 'Entrez une adresse e-mail valide, il doit ressembler à ceci "a@a.aa" au minimum.';
        res = false;
    }else{
        emailHelp.textContent = ""
    }



    // Pour vérifier que le numéro de téléphone a la bonne syntaxe
    const phoneField = document.getElementById('phone');
    const phoneHelp = document.getElementById('phoneHelp');
    let phone = phoneField.value;
    let regexPhone = /^\d{10}$/;

    if (!regexPhone.test(phone)) {
        phoneHelp.textContent = 'Entrez un numéro de téléphone valide avec 10 chiffres';
        res = false;
    }else{
        phoneHelp.textContent = ""
    }



    // Affiche un message pour prévenir l'utilisateur d'informations saisies incorrectes
    const ajouterHelp = document.getElementById('ajouterHelp');

    if (res === false) {
        ajouterHelp.textContent = "Veuillez vérifier les informations et relancez !";
    }

    return res;

}