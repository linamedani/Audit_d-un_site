document.addEventListener("DOMContentLoaded", function() {
    var form = document.querySelector('form');
    var departmentsCheckbox = document.querySelectorAll('input[name="departements[]"]');
    var yearSelect = document.querySelector('select[name="annee"]');
    var semesterRadios = document.querySelectorAll('input[name="semestre"]');

    // Fonction pour vérifier si au moins un département est sélectionné
    function isDepartmentSelected() {
        return Array.from(departmentsCheckbox).some(function(checkbox) {
            return checkbox.checked;
        });
    }

    // Fonction pour vérifier si une année et un semestre ont été sélectionnés
    function isYearSemesterSelected() {
        return yearSelect.value !== "Choississez une option" && Array.from(semesterRadios).some(function(radio) {
            return radio.checked;
        });
    }

    // Ajoute un gestionnaire d'événements à l'événement submit du formulaire
    form.addEventListener('submit', function(event) {
        if (isDepartmentSelected()) {
            var errorMessage = '';
            if (!isYearSemesterSelected()) {
                // Si une année et un semestre ne sont pas sélectionnés
                if (yearSelect.value === "Choississez une option" && !Array.from(semesterRadios).some(function(radio) { return radio.checked; })) {
                    errorMessage = 'Veuillez sélectionner une année et un semestre.';
                } else if (yearSelect.value === "Choississez une option") {
                    errorMessage = 'Veuillez sélectionner une année.';
                } else {
                    errorMessage = 'Veuillez sélectionner un semestre.';
                }
                event.preventDefault();
                alert(errorMessage);
            }
        }
    });
});
