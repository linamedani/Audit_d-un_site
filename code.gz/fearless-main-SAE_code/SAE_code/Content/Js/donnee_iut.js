function validerForm() {
	const choix = document.querySelector('input[name="choix"]:checked');
	const filter = document.querySelector('input[name="filter"]:checked');

	if (!choix) {
		alert("Veuillez sélectionner une option parmi Année, Semestre, Département, Discipline, Formation.");
		return false;
	}

	if (!filter) {
		alert("Veuillez sélectionner une option parmi Heures, Statut.");
		return false;
	}

	return true;
}

    window.onload = function() {
        var departementCheckboxes = document.querySelectorAll('input[name="departements[]"]');
        var semestreSelect = document.querySelector('select[name="semestre"]');
        var anneeSelect = document.querySelector('select[name="annee"]');

        // Fonction pour activer ou désactiver les champs de sélection du semestre et de l'année
        function toggleSemestreAnneeFields(enable) {
            semestreSelect.disabled = !enable;
            anneeSelect.disabled = !enable;
        }

        // Gestionnaire d'événements pour surveiller les changements dans la sélection du département
        departementCheckboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                // Vérifie si au moins un nouveau département est sélectionné
                var isNewDepartementSelected = Array.from(departementCheckboxes).some(function(checkbox) {
                    return checkbox.checked;
                });

                // Active ou désactive les champs de sélection du semestre et de l'année en fonction de la sélection du département
                toggleSemestreAnneeFields(isNewDepartementSelected);
            });
        });
    };