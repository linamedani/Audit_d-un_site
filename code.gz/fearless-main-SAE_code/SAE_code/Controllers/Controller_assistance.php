<?php 

class Controller_assistance extends Controller {


    /**
     * Affiche la page d'assistance avec les informations du profil de l'utilisateur
     * @return void
     */
    public function action_assitance(){
        $m = Model::getModel();
        // Récupère les informations du profil de l'utilisateur via le modèle
        $this->render("assistance", ["profil" => $m->getInfoProfil($_SESSION['id'])]);
    }

    /**
     * Traite la soumission du formulaire d'assistance
     * @return void
     */
    public function action_send(){
        if (isset($_POST['objet'])&& isset($_POST['demande'])) {
            $m = Model::getModel();
            $objet = $_POST['objet'];
            $demande = $_POST['demande'];
            $id = $_SESSION['id'];

            // Enregistrement de la demande d'assistance
            $m->enregistreMessage($id, $objet, $demande);
        
            // Redirection vers la page de confirmation ou un message de succès
          
            $this->render("message", ["title" => ":)", "message" => "votre message a été bien envoyé!"]);
        }
    }

    /**
     * Action par défaut, redirige vers l'action assistance
     * @return void
     */
    public function action_default(){
        $this->action_assitance();
    }
    
   

}

?>