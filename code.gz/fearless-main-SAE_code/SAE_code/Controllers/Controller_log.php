<?php 
class Controller_log extends Controller {

    /**
     * Récupération et affichage des logs
     * @return void
     */
    public function action_log(){
        $m=Model::getModel();
        $data['log']=$m->getLog();
        $this->render("log",$data);
    }

    /**
     * @return void
     */
    public function action_default(){
        $this->action_log();
    }
}
