<?php
class Controller_annuaire extends Controller {


    /**
     * Affiche la liste des 50 premières personnes de l'annuaire
     * @return void
     */
    public function action_annuaire(){
        $m = Model::getModel();
        $data = ["infos" => $m->getList()];
        $this->render("annuaire", $data);
    }



    /**
     * Action par défaut, redirige vers l'action annuaire
     * @return void
     */
    public function action_default(){
        $this->action_annuaire();
    }



    /**
     * Affiche le formulaire pour ajouter une nouvelle personne
     * @return void
     */
    public function action_ajouter(){
        $this->render("ajouter");
    }


    /**
     * Affiche le formulaire d'ajout avec les informations requises pour les listes déroulantes
     * @return void
     */
    public function action_ajouter_form(){
        $m = Model::getModel();
        $data = [
            "list" => $m->getCatDiscDpt(), 
            "annee" => $m->getAnnee(), 
            "semestre" => $m->getSemestre()
        ];
        $this->render("form_ajouter", $data);
    }


    /**
     * Valide et enregistre les informations soumises par l'utilisateur
     * @return void
     */
    public function action_validation(){
        $m = Model::getModel();
        // Vérifie que l'ID est un nombre et qu'il n'existe pas déjà dans la base de données
        if (!$m->id_exist_in_db($_POST["id"])) {
            $infos["poste"] = $_POST["poste"];
            $infos["id"] = $_POST["id"];
            $infos["fonction"] = $_POST["poste"];
            $infos["nom"] = $_POST["nom"];
            $infos["prenom"] = $_POST["prenom"];
            $infos["email"] = $_POST["email"];
            $infos["phone"] = $_POST["phone"];
            $infos["mdp"] = password_hash($_POST["mdp"], PASSWORD_DEFAULT);

            // Si le poste est "enseignant", ajoute des informations supplémentaires
            if ($_POST["poste"] == "enseignant") {
                $infos["annee"] = $_POST["annee"];
                $infos["semestre"] = $_POST["semestre"];
                $infos["statut"] = $_POST["statut"];
                $infos["discipline"] = $_POST["discipline"];
                $infos["direction"] = $_POST["direction"];
                if (isset($_POST["departements"])) {
                    $infos["departements"] = $_POST["departements"];
                }
            }

            // Ajoute l'utilisateur dans la base de données
            $m->ajouterUtilisateur($infos);
            $this->render("message", ["title" => ":)", "message" => "Ajouté avec succès !"]);
        } else {
            // Affiche un message d'erreur si les informations sont invalides
            $this->render("message", ["title" => ":)", "message" => "Oups! L'id existe déjà","success_form_ajouter" => false,"couleur" => "red", "poste" => $_POST["poste"]]);
        }
    }



    /**
     * Supprime un utilisateur si l'utilisateur connecté a les permissions nécessaires
     * @return void
     */
    public function action_supprimer(){
        if (isset($_SESSION["permission"]) && $_SESSION["permission"] == "direction") {
            $m = Model::getModel();
            $m->supprimerUtilisateur($_GET["id"]);
            $this->action_default();
        }
    }
}
?>