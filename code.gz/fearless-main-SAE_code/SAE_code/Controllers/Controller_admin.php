<?php 

class Controller_admin extends Controller {

    /**
     * Affiche les messages envoyés par le formulaire d'assistance  
     * @return void
    **/
    public function action_message() {
        // Vérification si l'utilisateur est administrateur
        if ($_SESSION['id'] == 123) {
            $m = Model::getModel();
            $messages = $m->getAssistanceMessages();
            $this->render("admin_assistance", ["messages" => $messages]);
        } else {
            // Redirige vers une page d'erreur ou la page d'accueil si l'utilisateur n'est pas autorisé
            $this->render("error", ["message" => "Vous n'êtes pas autorisé à accéder à cette page."]);
        }
    }
    /**
     * Action par défaut, redirige vers l'action message
     * @return void
     */
    public function action_default(){
        $this->action_message();
    }
}
?>
