<?php 
class Controller_profil extends Controller {


    /**
     * Affiche les informations du profil de l'utilisateur
     * @return void
     */
    public function action_profil(){
        $m = Model::getModel();
        // Vérifie si un ID est spécifié dans l'URL et s'il existe dans la base de données
        if(isset($_GET["id"]) and $m->id_exist_in_db($_GET["id"])){
            $data = $m->getInfoProfil($_GET["id"]);
        }
        // Si aucun ID spécifié ou si l'ID spécifié n'existe pas, affiche le profil de l'utilisateur connecté
        else {
            $data = $m->getInfoProfil($_SESSION["id"]);
        }
        $this->render("profil", $data);
    }


    /**
     * Action par défaut, redirige vers l'action profil
     * @return void
     */
    public function action_default(){
        $this->action_profil();
     } 



    /**
     * Affiche la page de modification du profil
     * @return void
     */
    public function action_modification(){
        $m = Model::getModel();
        $id = $_SESSION["id"];

        // Si l'utilisateur est administrateur, utilise l'ID du profil qu'il regarde, sinon utilise l'ID de la session
        if(isset($_GET["id"]) and $_SESSION["permission"] == "direction"){
            $id = $_GET["id"];
        }
        // Récupère les informations du profil à modifier ainsi que les données nécessaires pour les listes déroulantes
        $data = ['profil'=> $m->getInfoProfil($id),'list'=> $m->getCatDiscDpt(),'annee' => $m->getAnnee(), "semestre" => $m->getSemestre()];
        // Rend la vue de modification avec les données récupérées
        $this->render("modification", $data);
    }



    /**
     * Modification des données du profil de l'utilisateur
     * @return void
     */
    public function action_modifier(){
        if(isset($_POST["id"])){
            $infos["id"] = $_POST["id"];
            // Récupère les données du formulaire
            if(!empty($_POST["nom"])){
                $infos["nom"] = $_POST["nom"];}
                if(!empty($_POST["prenom"])){
                $infos["prenom"] = $_POST["prenom"];}
                if(!empty($_POST["email"])){
                $infos["email"] = $_POST["email"];}
                if(!empty($_POST["phone"])){
                $infos["phone"] = $_POST["phone"];}
            // Vérifie si un nouveau mot de passe est fourni
            if(empty($_POST["mdp"])){
                $infos['mdp'] = null; // Garde le mot de passe existant si aucun nouveau n'est fourni
            } else {
                $infos["mdp"] = password_hash($_POST["mdp"], PASSWORD_DEFAULT); // Hash le nouveau mot de passe
            }
            // Vérifie le type de fonction de l'utilisateur
            if(isset($_POST["annee"])&& $_POST["annee"] !== "Choississez une option"){
                $infos['annee'] = $_POST["annee"];}
                if(isset($_POST["semestre"]) && $_POST["semestre"] !== "Choississez une option"){
                $infos['semestre'] = $_POST["semestre"];}
                if(isset($_POST["statut"])){
                $infos["statut"] = $_POST["statut"];}
                if(isset($_POST["discipline"])){
                $infos["discipline"] = $_POST["discipline"];}
                if(isset($_POST["departements"])){
                $infos["departements"] = $_POST["departements"];}
            $infos["fonction"] = $_POST["fonction"];
            // Met à jour le profil avec les nouvelles données
            $m = Model::getModel();
            $m->updateProfil($infos);
            $this->action_default();
        } else {
            // Affiche un message d'erreur si aucune donnée n'a été reçue pour la modification
            $this->render("message", ["title" => "Erreur modification profil","message" => "La modification n'a pas fonctionnée."]);
        }
    }
}
?>