<?php 
class Controller_declaration extends Controller {


    /**
     * Affiche le formulaire de déclaration avec les informations nécessaires
     * @return void
     */
    public function action_declaration(){
        $m = Model::getModel();
        // Récupère les années, semestres et départements via le modèle
        $data = ["annee" => $m->getAnnee(), "semestre" => $m->getSemestre(), "departement" => $m->getDpt()];
        $this->render("declaration_form", $data);
    }



    /**
     * Action par défaut, redirige vers l'action declaration
     * @return void
     */
    public function action_default(){
        $this->action_declaration();
    }


    /**
     * Valide et ajoute l'heure déclarée dans la base de données
     * @return void
     */
    public function action_validation(){
        $m = Model::getModel();
        // Vérifie si toutes les données nécessaires sont présentes dans la requête POST
        if (isset($_POST["annee"]) && isset($_POST["semestre"]) && isset($_POST["dept"]) && isset($_POST["heure"]) && isset($_POST["type_h"])) {
            // Vérifie si l'heure est un nombre
            if (isNumber($_POST["heure"])) {
                // Ajoute l'heure déclarée dans la base de données
                $m->ajouterHeure();
                $success = true;
                // Rend un message de succès
                $this->render("message", ["title" => ":)", "message" => "Ajout réussi !", "success" => $success, "couleur" => ($success ? "white2" : "red")]);
            } else {
                // Affiche un message d'erreur si l'heure n'est pas un nombre
                $message = "L'heure n'est pas valide! Veuillez saisir des chiffres";
                $success = false;
                // Rend un message d'erreur avec le message spécifique
                $this->render("message", ["title" => ":)", "message" => "L'heure n'est pas valide! Veuillez saisir des chiffres !", "success" => $success, "couleur" => ($success ? "white2" : "red")]);
            }
        } else {
            // Affiche un message d'erreur si les informations nécessaires sont manquantes dans la requête POST
            $this->action_error("Informations non valide !");
        }
    }
}
?>