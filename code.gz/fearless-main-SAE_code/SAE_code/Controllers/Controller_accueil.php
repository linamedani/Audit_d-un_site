<?php

/**
 * Contrôleur pour la page d'accueil
 */
class Controller_accueil extends Controller {

    /**
     * Affiche la page d'accueil et, si l'utilisateur est connecté, récupère ses informations de profil
     * @return void
     */
    public function action_accueil(){
        $m = Model::getModel();
        $data = [];
        // Vérifie si l'utilisateur est connecté et récupère les informations de son profil
        if(isset($_SESSION["id"])){
            $data = $m->getInfoProfil($_SESSION["id"]);
        }
        $this->render("accueil", $data);
    }

    /**
     * Redirige vers l'action accueil par défaut
     * @return void
     */
    public function action_default(){
        $this->action_accueil();
    }
}
?>