<?php
class Controller_departement extends Controller {

    /**
     * @return void
     */
    public function action_departement(){
   // tester permissions si l'utilisateur a les droits de voir la page, sinon afficher la page
        if($_SESSION["permission"]=="chefdedpt"){
            $m=Model::getModel();
            $data['info']=$m->getInfoDepartement($_SESSION["id"]);
            $data['nomf']=$m->getNomFormationPropose($data['info']['iddepartement']);
            $data['effectif']=$m->getEffectifDpt($data['info']['iddepartement']);
            $data['besoinh']=$m->getBesoinHeureDpt($data['info']['iddepartement']);
            $this->render("departement",$data);
            
        }
        elseif($_SESSION["permission"]=="direction"){
            // Si l'utilisateur est de la direction, affiche la liste des départements
            $m=Model::getModel();
            $data["libelledept"] = $m->getNomDepartement();
            if(isset($_GET["id"])){
                // Si un département est sélectionné, affiche les informations spécifiques à ce département
                $data["info"]=$m -> getInfoDepartement2($_GET["id"]);
                $data['nomf']=$m->getNomFormationPropose($data['info']['iddepartement']);
                $data['effectif']=$m->getEffectifDpt($data['info']['iddepartement']);
                $data['besoinh']=$m->getBesoinHeureDpt($data['info']['iddepartement']);
                $this->render("departement",$data);
            }
            // Affiche la liste des départements par défaut
            $this->render("list_dpt",$data);
        }
        // Si l'utilisateur n'a pas les permissions nécessaires, affiche un message d'erreur
        $this->action_error("Vous n'avez pas les permissions");
    }



    /**
     * Affiche le formulaire de demande
     * @return void
     */
    public function action_demande(){
        // Vérifie les permissions de l'utilisateur
        if($_SESSION["permission"]=="chefdedpt" || $_SESSION["permission"]=="direction") {
            // Si l'utilisateur a les permissions nécessaires, récupère les données pour le formulaire
            $m=Model::getModel();
           
            $data = ["annee" => $m->getAnnee(), "semestre" => $m->getSemestre(),"departement" => $m->getDpt(), "discipline" => $m->getDiscipline(), "formation"=>$m->getFormation()];
            $this->render("demande_form",$data);
        }
        // Redirige vers l'action par défaut si l'utilisateur n'a pas les permissions nécessaires
        $this->action_default();
    }


    /**
     * Valide et traite la demande
     * @return void
     */
    public function action_validation() {
        $m=Model::getModel();
        // Vérifie si le besoin est bien un nombre
       if(isNumber($_POST["besoin"])){
            // Si le besoin est valide, ajoute la demande dans la base de données
            $m->ajouterBesoin();
            $sucs=true;
            // Affiche un message de succès
            $this->render("message", ["title" => ":)","message" => "Envoi réussi !","sucs" => $sucs]);
        }
        else{
            // Si le besoin n'est pas valide, affiche un message d'erreur
            $this->action_error("Informations non valide !");
        }
    }


    /**
     * Action par défaut, redirige vers l'action département
     * @return void
     */
    public function action_default(){
        $this->action_departement();
    }

}
