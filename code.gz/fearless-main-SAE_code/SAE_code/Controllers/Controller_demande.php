<?php 
class Controller_demande extends Controller {


    /**
     * Affiche la liste des demandes
     * @return void
     */
    public function action_demande(){
        $m = Model::getModel();
        $data['demande'] = $m->getDemande();
        $this->render("demande", $data);
    }



    /**
     * Action par défaut, redirige vers l'action demande
     * @return void
     */
    public function action_default(){
        $this->action_demande();
    }
}
?>