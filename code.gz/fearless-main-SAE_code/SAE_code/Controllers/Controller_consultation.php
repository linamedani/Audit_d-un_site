<?php
class Controller_consultation extends Controller {


    /**
     * Affiche la consultation des heures pour l'utilisateur connecté
     * @return void
     */
    public function action_consultation(){
        $m = Model::getModel();
        // Récupère les heures et les informations du profil de l'utilisateur
        $data["data"] = $m->getHeure($_SESSION["id"]);
        $data["profil"] = $m->getInfoProfil($_SESSION["id"]);
        $this->render("consultation_heure", $data);
    }



    /**
     * Affiche les informations sur l'IUT
     * @return void
     */
    public function action_iut(){
        $m = Model::getModel();
        $data["data"] = $m->getIUT();
        $this->render("consultation_iut", $data);
    }



    /**
     * Action par défaut, redirige vers l'action consultation
     * @return void
     */
    public function action_default(){
        $this->action_consultation();
    }
}
?>