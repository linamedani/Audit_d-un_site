<?php


/**
 * Fonction échappant les caractères html dans $message
 * @param string $message chaîne à échapper
 * @return string chaîne échappée
 */
function e($message){
    return htmlspecialchars($message, ENT_QUOTES);
}


/**
 * Fonction qui renvoi le regex selon le type qui est soit "non_vide" soit "identifiant"
 * Fonction qui pourrait servir en intégrant constament des nouveaux regex utilisés dans le projet ce qui permet une intégration continue
 * @param $type
 * @return string
 */
function generateRegex($type) {
    switch ($type) {
        case 'identifiant':
            return '/^[0-9]+$/'; 
        default:
            throw new InvalidArgumentException("Type non supporté : " . $type);
    }
}

/**
 * Fonction pour vérifier si une valeur est bien un nombre,
 * Similaire à is_numeric() mais pas utilisable pour vérifier un id qui sera envoyé dans une requête SQL.
 * Donc cette fonction permet de généraliser le fait de savoir si une valeur est un nombre
 * @param $value
 * @return false|int
 */
function isNumber($value){
    return preg_match(generateRegex('identifiant'), $value);
}


/**
 * Fonction pour vérifier si un utilisateur n'est ni un secretaire ni une personne.
 * @param $entity
 * @return bool
 */
function notIsSecretaireAndPersonne($entity){
    return $entity != "secretaire" and $entity != "personne";
}
