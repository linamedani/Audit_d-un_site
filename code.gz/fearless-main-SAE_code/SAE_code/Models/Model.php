<?php

class Model
{
    /**
     * Attribut contenant l'instance PDO
     */
    private $bd;

    /**
     * Attribut statique qui contiendra l'unique instance de Model
     */
    private static $instance = null;

    /**
     * Constructeur : effectue la connexion à la base de données.
     */
    private function __construct(){
        require "credentials.php";
        $this->bd = new PDO($dsn, $login, $mdp);
        $this->bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->bd->query("SET nameS 'utf8'");
    }

    /**
     * Méthode permettant de récupérer un modèle car le constructeur est privé (Implémentation du Design Pattern Singleton)
     */
    public static function getModel(){
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }


    /**
     * Fonction qui vérifie le mot de passe
     * @return false|mixed
     */
    public function identification_Check(){
        /*
        On vérifie avant que les données sont bien transmisse et qu'elle correspondent aux type attendu
        La requete renvoie le mot de passe crypté qui a été enregistré dans la base de donnée à l'id donné
        Si une des conditions n'est pas rempli on renvoie false
        */
        if(isset($_POST["id"]) and isset($_POST["mdp"]) and isNumber($_POST["id"])){
            $requete = $this->bd->prepare("SELECT id_personne AS id, motDePasse AS mdp, grade(:id) AS fonction FROM personne WHERE id_personne = :id");
            $requete->bindValue(":id",$_POST["id"]);
            $requete->execute();
            return $requete->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    /**
     * @param $infos
     * @return void
     */
    public function ajouterUtilisateur($infos){
        // Préparation de la requête d'insertion pour ajouter une nouvelle personne dans la table "personne"
        $requete = $this->bd->prepare('INSERT INTO personne (id_personne, nom, prenom, email, phone, motDePasse) VALUES (:id, :nom, :prenom, :email, :phone, :mdp)');
        
        // Liaison des valeurs fournies dans le tableau $infos aux paramètres de la requête
        $requete->bindValue(":id", $infos["id"]);
        $requete->bindValue(":nom", $infos["nom"]);
        $requete->bindValue(":prenom", $infos["prenom"]);
        $requete->bindValue(":email", $infos["email"]);
        $requete->bindValue(":phone", $infos["phone"]);
        $requete->bindValue(":mdp", $infos["mdp"]);
        
        // Exécution de la requête d'insertion
        $requete->execute();
        
        // Vérification du poste de l'utilisateur pour déterminer les autres insertions à effectuer
        if($infos["poste"] == "enseignant"){
            // Préparation de la requête d'insertion pour ajouter un enseignant dans la table "enseignant"
            $requete = $this->bd->prepare(
                "INSERT INTO enseignant (id_personne, idDiscipline, id_categorie, AA) 
                VALUES (:id, (SELECT idDiscipline FROM discipline WHERE libelledisc = :disc), 
                (SELECT id_categorie FROM categorie WHERE siglecat = :statut), :annee)"
            );
            $requete->bindValue(":id", $infos["id"]);
            $requete->bindValue(":disc", $infos["discipline"]);
            $requete->bindValue(":statut", $infos["statut"]);
            $requete->bindValue(":annee", $infos["annee"]);
            $requete->execute();
            // Vérification et insertion des départements assignés à l'enseignant
            if(isset($infos["departements"])){
                foreach ($infos["departements"] as $v) {
                    $requete = $this->bd->prepare(
                        "INSERT INTO assigner (id_personne, idDepartement, AA, S) 
                        VALUES (:id, (SELECT idDepartement FROM departement WHERE libelledept = :libDept), :annee, :semestre)"
                    );
                    $requete->bindValue(":id", $infos["id"]);
                    $requete->bindValue(":libDept", $v);
                    $requete->bindValue(":annee", $infos["annee"]);
                    $requete->bindValue(":semestre", $infos["semestre"]);
                    $requete->execute();
                }
            }
            
            // Vérification et insertion de l'utilisateur dans l'équipe de direction s'il est un dirigeant
            if($infos["direction"] == "true"){
                $requete = $this->bd->prepare("INSERT INTO equipedirection (id_personne) VALUES (:id)");
                $requete->bindValue(":id", $infos["id"]);
                $requete->execute();
            }
        } else {
            // Si l'utilisateur est une secrétaire, insertion dans la table "secretaire"
            $requete = $this->bd->prepare("INSERT INTO secretaire (id_personne) VALUES (:id)");
            $requete->bindValue(":id", $infos["id"]);
            $requete->execute();
        }
    }


    /**
     * @param $id
     * @return bool
     */
    public function id_exist_in_db($id){
        // On selectionne seulement l'id de l'utilisateur pour réduire au maximum les recherches de la base de données
        $requete = $this->bd->prepare('SELECT id_personne FROM personne WHERE :id = id_personne');
        $requete->bindValue(":id",$id);
        $requete->execute();
        $res = $requete->fetch(PDO::FETCH_NUM);
        // Retourne un booléen si la requête a trouvé quelque chose ou pas
        return $res != false;
    }

    /**
     * Récupère les catégories, disciplines et départements de la base de données
     * @return array
     */
    public function getCatDiscDpt() {
    // Prépare et exécute la requête pour obtenir les catégories
    $requete = $this->bd->prepare('SELECT sigleCat FROM categorie order by sigleCat');
    $requete->execute();
    // Stocke les résultats des catégories dans le tableau associatif
    $data["statut"] = $requete->fetchAll(PDO::FETCH_ASSOC);

    // Prépare et exécute la requête pour obtenir les disciplines
    $requete = $this->bd->prepare('SELECT libelleDisc FROM discipline order by libelleDisc');
    $requete->execute();
    // Stocke les résultats des disciplines dans le tableau associatif
    $data["discipline"] = $requete->fetchAll(PDO::FETCH_ASSOC);

    // Prépare et exécute la requête pour obtenir les départements
    $requete = $this->bd->prepare('SELECT libelleDept FROM departement order by libelleDept');
    $requete->execute();
    // Stocke les résultats des départements dans le tableau associatif
    $data["departements"] = $requete->fetchAll(PDO::FETCH_ASSOC);

    // Retourne le tableau associatif contenant les données
    return $data;
}

    /**
     * Récupère une liste paginée des utilisateurs de la base de données
     * @param $offset
     * @param $limit
     * @param $order
     * @return array|false
     */
    public function getList($offset = 0, $limit = 50, $order = "nom") {
    // Vérifie s'il y a une recherche définie et valide
    if(isset($_GET["recherche"]) && !empty($_GET["recherche"])) {
        // Prépare la requête avec recherche si le paramètre "recherche" est défini
        $requete = $this->bd->prepare("SELECT id_personne, nom, prenom, grade(id_personne) AS fonction 
                                        FROM personne 
                                        WHERE nom ~* :rech OR prenom ~* :rech 
                                        ORDER BY nom 
                                        LIMIT :limit OFFSET :offset");
        // Lie la valeur de recherche au paramètre de la requête
        $requete->bindValue(":rech", $_GET["recherche"], PDO::PARAM_STR);
    } else {
        // Prépare la requête sans recherche si le paramètre "recherche" n'est pas défini
        $requete = $this->bd->prepare("SELECT id_personne, nom, prenom, grade(id_personne) AS fonction 
                                        FROM personne 
                                        ORDER BY nom 
                                        LIMIT :limit OFFSET :offset");
    }
    
    // Lie les paramètres limit et offset aux valeurs de la requête
    $requete->bindValue(':limit', $limit, PDO::PARAM_INT);
    $requete->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    // Exécute la requête
    $requete->execute();
    
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Récupère les informations du profil d'un utilisateur à partir de son ID
     * @param $id
     * @return mixed
     */
    public function getInfoProfil($id) {
    // Prépare la requête pour obtenir les informations de base de l'utilisateur
    $requete = $this->bd->prepare("SELECT id_personne as id, nom, prenom, email, phone, grade(:id) AS fonction 
                                   FROM personne WHERE id_personne = :id");
    // Lie l'ID de l'utilisateur au paramètre de la requête
    $requete->bindValue(':id', $id);
    // Exécute la requête
    $requete->execute();
    // Récupère les informations de base de l'utilisateur sous forme de tableau associatif
    $infos = $requete->fetch(PDO::FETCH_ASSOC);

    // Vérifie si l'utilisateur n'est pas un secrétaire ou une personne sans fonction spécifique
    if(notIsSecretaireAndPersonne($infos["fonction"])) {
        // Prépare la requête pour obtenir les informations spécifiques des enseignants
        $requete = $this->bd->prepare("SELECT libelledisc AS discipline, siglecat AS statut 
                                       FROM enseignant 
                                       JOIN categorie USING (id_categorie) 
                                       JOIN discipline USING (idDiscipline) 
                                       WHERE id_personne = :id");
        // Lie l'ID de l'utilisateur au paramètre de la requête
        $requete->bindValue(':id', $id);
        // Exécute la requête
        $requete->execute();
        // Fusionne les informations spécifiques des enseignants avec les informations de base
        $infos = array_merge($infos, $requete->fetch(PDO::FETCH_ASSOC));

        // Prépare la requête pour obtenir les départements assignés à l'enseignant
        $requete = $this->bd->prepare("SELECT libelleDept AS depts 
                                       FROM assigner 
                                       JOIN departement USING (idDepartement) 
                                       WHERE assigner.id_personne = :id");
        // Lie l'ID de l'utilisateur au paramètre de la requête
        $requete->bindValue(":id", $id);
        // Exécute la requête
        $requete->execute();
        // Ajoute les départements assignés aux informations de l'utilisateur
        $infos["depts"] = $requete->fetchAll(PDO::FETCH_ASSOC);
    }
    return $infos;
}

    /**
     * Supprime un utilisateur de la base de données à partir de son ID
     * @param $id
     * @return void
     */
    public function supprimerUtilisateur($id) {
    $requete = $this->bd->prepare("DELETE FROM personne WHERE id_personne = :id");
    $requete->bindValue(':id', $id);
    $requete->execute();
}

    /**
     * Récupère les informations d'un département à partir de l'ID d'une personne
     * @param $id
     * @return mixed
     */
    public function getInfoDepartement($id) {
    $requete = $this->bd->prepare("SELECT * FROM departement WHERE id_personne = :id");
    $requete->bindValue(':id', $id);
    $requete->execute();
    // Récupère les informations du département sous forme de tableau associatif
    $infos = $requete->fetch(PDO::FETCH_ASSOC);
    // Retourne les informations du département
    return $infos;       
}

    /**
     * Met à jour le profil d'un utilisateur dans la base de données
     * @param $infos
     * @return void
     */
    public function updateProfil($infos){
        if ($infos['mdp'] == null){
        $requete = $this->bd->prepare("UPDATE personne SET nom = :nom, prenom = :prenom, email = :email, phone = :phone WHERE id_personne = :id");
        $requete->bindValue(":id",$infos["id"]);
        $requete->bindValue(":nom",$infos["nom"]);
        $requete->bindValue(":prenom",$infos["prenom"]);
        $requete->bindValue(":email",$infos["email"]);
        $requete->bindValue(":phone",$infos["phone"]);
        $requete->execute();
        } else {
            $requete = $this->bd->prepare("UPDATE personne SET nom = :nom, prenom = :prenom, email = :email, phone = :phone, motdepasse = :mdp WHERE id_personne = :id");
            $requete->bindValue(":id",$infos["id"]);
            $requete->bindValue(":nom",$infos["nom"]);
            $requete->bindValue(":prenom",$infos["prenom"]);
            $requete->bindValue(":email",$infos["email"]);
            $requete->bindValue(":phone",$infos["phone"]);
            $requete->bindValue(":mdp", $infos["mdp"]);
            $requete->execute();
        }
        if(notIsSecretaireAndPersonne($infos["fonction"])){
            $requete = $this->bd->prepare("UPDATE enseignant SET idDiscipline = (SELECT idDiscipline FROM discipline WHERE libelledisc = :disc), 
                    id_categorie = (SELECT id_categorie FROM categorie WHERE siglecat = :statut) WHERE id_personne = :id");
            $requete->bindValue(":id",$infos["id"]);
            $requete->bindValue(":disc",$infos["discipline"]);
            $requete->bindValue(":statut",$infos["statut"]);
            $requete->execute();
        
            $requete = $this->bd->prepare("DELETE FROM assigner WHERE id_personne = :id");
            $requete->bindValue(":id", $infos["id"]);
            $requete->execute();
            if(isset($infos["departements"])){
                foreach ($infos["departements"] as $v) {
                    $requete = $this->bd->prepare("INSERT INTO assigner (id_personne, idDepartement, AA, S) 
                    VALUES (:id, (SELECT idDepartement FROM departement WHERE libelledept = :libDept),:annee,:semestre)");
                    $requete->bindValue(":id",$infos["id"]);
                    $requete->bindValue(":libDept",$v);
                    $requete->bindValue(":annee", $infos["annee"]);
                    $requete->bindValue(":semestre",$infos["semestre"]);
                    $requete->execute();
                }
            }
        }
    }

    
    /**
     * Récupère la liste des semestres distincts de la base de données
     * @return array|false
     */
    public function getSemestre() {
    $requete = $this->bd->prepare("SELECT DISTINCT S FROM semestre order by S");
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Récupère les noms et les IDs des départements de la base de données
     * @return array|false
     */
    public function getNomDepartement() {
    $requete = $this->bd->prepare("SELECT libelleDept, idDepartement AS id FROM departement");
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Récupère les informations d'un département à partir de son ID
     * @param $id
     * @return mixed
     */
    public function getInfoDepartement2($id) {
    $requete = $this->bd->prepare("SELECT * FROM departement WHERE idDepartement = :id");
    // Lie l'ID du département au paramètre de la requête
    $requete->bindValue(':id', $id);
    $requete->execute();
    // Récupère les informations du département sous forme de tableau associatif
    $infos = $requete->fetch(PDO::FETCH_ASSOC);
    return $infos;       
}


    /**
     * Récupère la liste des formations de la base de données
     * @return array|false
     */
    public function getFormation() {
    $requete = $this->bd->prepare('SELECT idFormation AS id, nom FROM formation');
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}


    /**
     * Récupère la liste des disciplines de la base de données
     * @return array|false
     */
    public function getDiscipline() {
    $requete = $this->bd->prepare('SELECT idDiscipline AS id, libelleDisc AS nom FROM discipline');
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Ajoute un besoin dans la base de données
     * @return void
     */
    public function ajouterBesoin() {
    // Supprime les besoins existants correspondant aux mêmes critères
    $requete = $this->bd->prepare('DELETE FROM besoin 
                                   WHERE aa = :annee 
                                   AND s = :semestre 
                                   AND iddepartement = (SELECT iddepartement FROM departement WHERE id_personne = :id) 
                                   AND iddiscipline = :discipline 
                                   AND idformation = :form');
    $requete->bindValue(":annee", $_POST["annee"]);
    $requete->bindValue(":semestre", $_POST["semestre"]);
    $requete->bindValue(":id", $_SESSION["id"]);
    $requete->bindValue(":discipline", $_POST["discipline"]);
    $requete->bindValue(":form", $_POST["formation"]);
    $requete->execute();
    // Insère le nouveau besoin
    $req = $this->bd->prepare('INSERT INTO besoin VALUES (:aa, :s, :idformation, :iddiscipline, (SELECT iddepartement FROM departement WHERE id_personne = :id), :besoin)');
    $req->bindValue(":aa", $_POST["annee"]);
    $req->bindValue(":s", $_POST["semestre"]);
    $req->bindValue(":idformation", $_POST["formation"]);
    $req->bindValue(":id", $_SESSION["id"]);
    $req->bindValue(":iddiscipline", $_POST["discipline"]);
    $req->bindValue(":besoin", $_POST["besoin"]);
    $req->execute(); 
}

    /**
     * Ajoute des heures d'enseignement pour un enseignant dans la base de données
     * @return void
     */
    public function ajouterHeure() {
    $requete = $this->bd->prepare('INSERT INTO enseigne (id_personne, idDiscipline, idDepartement, AA, S, nbHeureEns, typeH) 
                                   VALUES (:id, (SELECT idDiscipline FROM enseignant WHERE id_personne = :id), :idDpt, :aa, :s, :nbHE, :typeH)');
    $requete->bindValue(":id", $_SESSION["id"]);
    $requete->bindValue(":aa", $_POST["annee"]);
    $requete->bindValue(":s", $_POST["semestre"]);
    $requete->bindValue(":nbHE", $_POST["heure"]);
    $requete->bindValue(":typeH", $_POST["type_h"]);
    $requete->bindValue(":idDpt", $_POST["dept"]);
    $requete->execute();
}

    /**
     * Récupère les années disponibles dans la base de données
     * @return array|false
     */
    public function getAnnee() {
    $requete = $this->bd->prepare("SELECT AA FROM annee");
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Récupère les départements disponibles dans la base de données
     * @return array|false
     */
    public function getDpt() {
    $requete = $this->bd->prepare('SELECT idDepartement AS id, libelleDept AS nom FROM departement');
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

    /**
     * Récupère les noms des formations proposées par un département spécifique
     * @param $id
     * @return array|false
     */
    public function getNomFormationPropose($id) {
    $requete = $this->bd->prepare('SELECT nom FROM propose JOIN formation USING (idformation) WHERE iddepartement = :id');
    $requete->bindValue(':id', $id);
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}


    /**
     * Récupère l'effectif du département spécifié
     * @param $id
     * @return mixed
     */
    public function getEffectifDpt($id) {
    $requete = $this->bd->prepare('SELECT COUNT(*) AS nb FROM assigner WHERE iddepartement = :id');
    $requete->bindValue(':id', $id);
    $requete->execute();
    return $requete->fetchColumn();
}

    /**
     * Récupère le total des besoins en heures du département spécifié
     * @param $id
     * @return mixed
     */
    public function getBesoinHeureDpt($id) {
    $requete = $this->bd->prepare('SELECT SUM(besoin_heure) FROM besoin WHERE iddepartement = :id');
    $requete->bindValue(':id', $id);
    $requete->execute();
    $res = $requete->fetchColumn();
    if(!isset($res)){
        $res = 0;
    }}

    /**
     * Récupère les demandes de besoins en heures
     * @return array|false
     */
    public function getDemande() {
        // Prépare la requête pour obtenir les demandes de besoins en heures
        $requete = $this->bd->prepare('SELECT DISTINCT besoin.*, demandes.*, personne.*, departement.*, discipline.* 
                                       FROM besoin 
                                       JOIN demandes USING (idDepartement) 
                                       JOIN personne USING (id_personne) 
                                       JOIN departement USING (iddepartement) 
                                       JOIN discipline USING (iddiscipline)');
        // Vérifie le niveau d'autorisation de l'utilisateur et filtre les résultats si c'est un chef de département
        if ($_SESSION['permission'] == 'chefdedpt') {
            $requete = $this->bd->prepare('SELECT DISTINCT besoin.*, demandes.*, personne.*, departement.*, discipline.* 
                                           FROM besoin 
                                           JOIN demandes USING (idDepartement) 
                                           JOIN personne USING (id_personne) 
                                           JOIN departement USING (iddepartement) 
                                           JOIN discipline USING (iddiscipline) 
                                           WHERE demandes.id_personne = :id');
            $requete->bindValue(':id', $_SESSION['id']);
        }
        $requete->execute();
        // Retourne les résultats sous forme de tableau associatif
        return $requete->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Récupère les logs de la base de données
     * @return array|false
     */
    public function getLog() {
    // Prépare la requête pour obtenir les logs, triés par date de modification décroissante
    $requete = $this->bd->prepare('SELECT * FROM log ORDER BY date_modif DESC');
    $requete->execute();
    // Retourne les résultats sous forme de tableau associatif
    return $requete->fetchAll(PDO::FETCH_ASSOC);
}


    /**
     * Récupère les heures d'enseignement en fonction du filtre spécifié
     * @param $id
     * @return array|false
     */
    public function getHeure($id) {
        // Vérifie s'il y a un filtre spécifié dans la requête POST
        if(isset($_POST["filter"])) {
            // Sélectionne la requête en fonction du filtre
            if($_POST["filter"] == "annee") {
                $requete = $this->bd->prepare('SELECT AA AS label, SUM(nbHeureEns) AS heures 
                                               FROM enseigne 
                                               JOIN departement USING (idDepartement) 
                                               WHERE enseigne.id_personne = :id 
                                               GROUP BY AA');
            } elseif($_POST["filter"] == "semestre") {
                $requete = $this->bd->prepare('SELECT S AS label, SUM(nbHeureEns) AS heures 
                                               FROM enseigne 
                                               JOIN departement USING (idDepartement) 
                                               WHERE enseigne.id_personne = :id 
                                               GROUP BY S');
            } elseif($_POST["filter"] == "departement") {
                $requete = $this->bd->prepare('SELECT libelleDept AS label, SUM(nbHeureEns) AS heures 
                                               FROM enseigne 
                                               JOIN departement USING (idDepartement) 
                                               WHERE enseigne.id_personne = :id 
                                               GROUP BY libelleDept');
            } else {
                $requete = $this->bd->prepare('SELECT typeH AS label, SUM(nbHeureEns) AS heures 
                                               FROM enseigne 
                                               JOIN departement USING (idDepartement) 
                                               WHERE enseigne.id_personne = :id 
                                               GROUP BY typeH');
            }
        } else {
            // Par défaut, affiche les heures en fonction du typeH
            $requete = $this->bd->prepare('SELECT typeH AS label, SUM(nbHeureEns) AS heures 
                                           FROM enseigne 
                                           JOIN departement USING (idDepartement) 
                                           WHERE enseigne.id_personne = :id 
                                           GROUP BY typeH');
        }
        // Lie l'ID de la personne au paramètre de la requête
        $requete->bindValue(':id', $id);
        $requete->execute();
        // Retourne les résultats sous forme de tableau associatif
        return $requete->fetchAll(PDO::FETCH_ASSOC);
    }



    /**
     * Récupère les données sur l'IUT en fonction des filtres spécifiés
     * @return array|false
     */
    public function getIUT() {
        // Vérifie s'il y a un filtre et un choix spécifiés dans la requête POST
        if(isset($_POST["filter"]) && isset($_POST["choix"])) {
            // Sélectionne la requête en fonction du choix et du filtre spécifiés
            if($_POST["choix"] == "annee") {
                if($_POST["filter"] == "heures") {
                    $requete = $this->bd->prepare('SELECT AA AS label, SUM(nbHeureEns) AS nb 
                                                   FROM enseigne 
                                                   JOIN departement USING (idDepartement) 
                                                   GROUP BY AA 
                                                   ORDER BY AA');
                } elseif($_POST["filter"] == "statut") {
                    $requete = $this->bd->prepare('SELECT AA AS label, sigleCat AS sigle, COUNT(sigleCat) AS nb 
                                                   FROM enseignant 
                                                   JOIN categorie USING (id_categorie) 
                                                   GROUP BY AA, sigleCat 
                                                   ORDER BY AA');
                }
            } elseif($_POST["choix"] == "semestre") {
                if($_POST["filter"] == "heures") {
                    $requete = $this->bd->prepare('SELECT AA AS label, S AS sigle, SUM(nbHeureEns) AS nb 
                                                   FROM enseigne 
                                                   JOIN departement USING (idDepartement) 
                                                   GROUP BY S, AA 
                                                   ORDER BY AA');
                } elseif($_POST["filter"] == "statut") {
                    $requete = $this->bd->prepare('SELECT sigleCat AS label, S AS sigle, COUNT(sigleCat) AS nb 
                                                   FROM enseignant 
                                                   JOIN categorie USING (id_categorie) 
                                                   JOIN semestre USING (AA) 
                                                   WHERE AA = 2024 
                                                   GROUP BY S, sigleCat');
                }
            } elseif($_POST["choix"] == "departement") {
                if($_POST["filter"] == "heures") {
                    $requete = $this->bd->prepare('SELECT AA AS sigle, libelleDept AS label, SUM(nbHeureEns) AS nb 
                                                   FROM enseigne 
                                                   JOIN departement USING (idDepartement) 
                                                   GROUP BY libelleDept, AA 
                                                   ORDER BY AA');
                } elseif($_POST["filter"] == "statut") {
                    $requete = $this->bd->prepare('SELECT libelleDept AS label, sigleCat AS sigle, COUNT(sigleCat) AS nb 
                                                   FROM enseignant 
                                                   JOIN categorie USING (id_categorie) 
                                                   JOIN enseigne USING (id_personne) 
                                                   JOIN departement USING (idDepartement) 
                                                   WHERE enseigne.AA = 2024 
                                                   GROUP BY sigleCat, libelleDept');
                }
            } elseif($_POST["choix"] == "discipline") {
                if($_POST["filter"] == "heures") {
                    $requete = $this->bd->prepare('SELECT libelleDisc AS label, AA AS sigle, SUM(nbHeureEns) AS nb 
                                                   FROM enseigne 
                                                   JOIN discipline USING (idDiscipline) 
                                                   GROUP BY AA, libelleDisc 
                                                   ORDER BY AA');
                } elseif($_POST["filter"] == "statut") {
                    $requete = $this->bd->prepare('SELECT libelleDisc AS label, sigleCat AS sigle, COUNT(sigleCat) AS nb 
                                                   FROM enseignant 
                                                   JOIN categorie USING (id_categorie) 
                                                   JOIN discipline USING (idDiscipline) 
                                                   GROUP BY sigleCat, libelleDisc');
                }
            } elseif($_POST["choix"] == "formation") {
                if($_POST["filter"] == "heures") {
                    $requete = $this->bd->prepare('SELECT AA AS sigle, nom AS label, SUM(besoin_heure) AS nb 
                                                   FROM besoin 
                                                   JOIN formation USING (idFormation) 
                                                   GROUP BY AA, nom 
                                                   ORDER BY AA');
                } elseif($_POST["filter"] == "statut") {
                    $requete = $this->bd->prepare('SELECT nom AS label, sigleCat AS sigle, COUNT(sigleCat) AS nb 
                                                   FROM enseignant 
                                                   JOIN categorie USING (id_categorie) 
                                                   JOIN enseigne USING (id_personne) 
                                                   JOIN departement USING (idDepartement) 
                                                   JOIN propose USING (idDepartement) 
                                                   JOIN formation USING (idFormation) 
                                                   WHERE enseigne.AA = 2024 
                                                   GROUP BY nom, sigleCat, libelleDept');
                }
            }
        } else {
            // Par défaut, affiche les heures par année
            $requete = $this->bd->prepare('SELECT AA AS label, SUM(nbHeureEns) AS nb 
                                           FROM enseigne 
                                           JOIN departement USING (idDepartement) 
                                           GROUP BY AA 
                                           ORDER BY AA');
        }
        $requete->execute();
        // Retourne les résultats sous forme de tableau associatif
        return $requete->fetchAll(PDO::FETCH_ASSOC);
    }
    /**
     * Enregistre les messages envoyés par le formulaire d'assistance
     * @param $id, $objet, $demande 
     * @return void
     */

    public function enregistreMessage($id, $objet, $demande) {
        // Vérification de l'existence d'un message similaire récent
        $checkQuery = $this->bd->prepare("SELECT COUNT(*) FROM assistance WHERE id_personne = :id AND objet = :objet AND demande = :demande AND date_creation > NOW() - INTERVAL '1 HOUR'");
        $checkQuery->bindValue(':id', $id);
        $checkQuery->bindValue(':objet', $objet);
        $checkQuery->bindValue(':demande', $demande);
        $checkQuery->execute();
        $count = $checkQuery->fetchColumn();
    
        if ($count == 0) {
            // Insertion du message si aucun message similaire récent n'existe
            $requete = $this->bd->prepare("INSERT INTO assistance (id_personne, objet, demande, date_creation) VALUES (:id, :objet, :demande, NOW())");
            $requete->bindValue(':id', $id);
            $requete->bindValue(':objet', $objet);
            $requete->bindValue(':demande', $demande);
            $requete->execute();
        }
    }
    /**
     * Récupère les messages de la table assistance avec l'id de la personne qui a envoyé le msg
     * @param $id
     * @return array|false
     */
    public function getAssistanceMessages() {
        $requete = $this->bd->prepare("SELECT p.id_personne, p.nom, p.prenom, a.objet, a.demande, a.date_creation
                                       FROM assistance a
                                       JOIN personne p ON a.id_personne = p.id_personne
                                       ORDER BY a.date_creation DESC");
        $requete->execute();
        return $requete->fetchAll(PDO::FETCH_ASSOC);
    }
    public function emailExiste($email) {
        $requete = $this->bd->prepare('SELECT COUNT() AS total FROM personne WHERE email = :email');
        $requete->bindParam(':email', $email);
        $requete->execute();
        $resultat = $requete->fetch(PDO::FETCH_ASSOC);
        return $resultat['total'] > 0;
    }

    public function updateResetToken($email, $token) {
        $requete = $this->bd->prepare('UPDATE personne SET reset_key = :token WHERE email = :email');
        $requete->bindValue(":token", $token);
        $requete->bindValue(":email", $email);
        $requete->execute();
    }

    public function getPersonneByToken($token) {
        $requete = $this->bd->prepare('SELECT FROM personne WHERE reset_key = :token');
        $requete->bindValue(":token", $token);
        $requete->execute();
        return $requete->fetch(PDO::FETCH_ASSOC);
    }

    public function changePasswordAndClearToken($personneId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        try {
            $this->bd->beginTransaction();

            $requete = $this->bd->prepare('UPDATE personne SET motDePasse = :hashedPassword WHERE id_personne = :personneId');
            $requete->bindValue(':hashedPassword', $hashedPassword);
            $requete->bindValue(':personneId', $personneId);
            $requete->execute();

            $requete = $this->bd->prepare('UPDATE personne SET reset_key = NULL WHERE id_personne = :personneId');
            $requete->bindValue(':personneId', $personneId);
            $requete->execute();

            $this->bd->commit();

            return true; // Succès
        } catch (Exception $e) {
            $this->bd->rollBack();
            return false; // Échec
        }
    }
}