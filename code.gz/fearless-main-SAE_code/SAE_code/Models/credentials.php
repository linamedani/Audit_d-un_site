<?php 

$dsn = 'pgsql:host=localhost;dbname=postgres';
$login = '';
$mdp = '';

?>
